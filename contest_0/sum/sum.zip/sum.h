#pragma once

#include <cstdint>

int64_t Sum(int64_t, int64_t);